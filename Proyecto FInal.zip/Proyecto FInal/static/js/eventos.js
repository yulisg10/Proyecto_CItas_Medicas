$(document).ready(function(){
/*
	//Menú
	var condition = false;

	$('#btn-menu').click(function() {
		if(!condition) {
			$('.container').css('left','300px');
			$('.container').css('transition','0.5s');
			condition = true;
		} else {
			$('.container').css('left','40px');
			$('.container').css('transition','0.5s');
			condition = false;
		}
	});
	*/
	

	
});
