# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import models

from django.contrib.auth.models import User
from modelos.usuario.models import Usuario
from modelos.medico.models import Medico

# Create your models here.

class CitaMedica(models.Model):
	
	usuario = models.ForeignKey(User,blank=True)
	medico = models.ForeignKey(Medico)
	fecha_cita = models.DateField(null=True, blank=True)
	hora_cita = models.DateTimeField(null=True, blank=True)
	fecha_solicitud = models.DateField(auto_now_add=True, blank=True)
	hora_solicitud = models.DateTimeField(auto_now_add=True, blank=True)
